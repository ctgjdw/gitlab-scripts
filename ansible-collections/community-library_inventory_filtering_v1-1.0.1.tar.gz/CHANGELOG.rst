==============================================================
Community Inventory Filtering Library Collection Release Notes
==============================================================

.. contents:: Topics

v1.0.1
======

Release Summary
---------------

Maintenance release with documentation.

v1.0.0
======

Release Summary
---------------

First production ready release.

v0.1.0
======

Release Summary
---------------

Initial test release.
